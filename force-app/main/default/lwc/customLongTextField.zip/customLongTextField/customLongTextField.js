import { LightningElement, api, track, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';

export default class CustomRichText extends LightningElement {
    @api recordId;
    @api objectApiName;
    @api fieldApiName;
    @api label = 'Contenido';

    @track value = '';

    // 🟦 Construimos dinámicamente el campo a consultar
    get fieldsToLoad() {
        return [`${this.objectApiName}.${this.fieldApiName}`];
    }
    // 🟦 Cargar valor inicial al abrir la página
    @wire(getRecord, { recordId: '$recordId', fields: '$fieldsToLoad' })
    wiredRecord({ error, data }) {
    if (data) {
        const field = data.fields[this.fieldApiName];
        this.value = field ? field.value : '';
    } else if (error) {
        console.error('Error cargando registro', error);
    }
}



    // 🟦 Actualizar valor al escribir
    handleChange(event) {
        this.value = event.target.value;
    }

    // 🟦 Guardar
    handleSubmit(event) {
        event.preventDefault();
        const fields = event.detail.fields;
        fields[this.fieldApiName] = this.value;
        this.template.querySelector('lightning-record-edit-form').submit(fields);
    }

    handleSuccess() {
        console.log('Guardado correcto');
    }

    handleError(event) {
        console.error('Error al guardar:', event.detail);
    }
}
